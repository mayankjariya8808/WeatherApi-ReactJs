import React from 'react'
import Home from '../Components/Home'

function Main() {
  return (
    <div className='mains'>
      <Home/>
    </div>
    
    
  )

}

export default Main