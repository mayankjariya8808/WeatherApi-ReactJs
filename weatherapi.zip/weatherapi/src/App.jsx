import logo from './logo.svg';
import Home from './Components/Home'
import './App.css';
import Main from './Components/Main'

function App() {
  return (
    <div className="App">
     <Home/>
         </div>
  );
}

export default App;

